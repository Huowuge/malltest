<script>
import {ref} from 'vue' 
export default{
  name: 'App',
  setup(){
    let person = ['小刚', '小红', '小白']  
    let tea = {  //这是一个对象数据
      green: '绿茶',
      black: '黑茶',
      wulong: '乌龙茶',
      foreign:{
        british: '英国茶',
        indian: '印度茶',
        africa: '非洲茶'
      }
    }
    //先将tea转化为数组，取出前三种茶
    let arrTea=[]
    for(let i in tea){
      arrTea.push(tea[i])
    }
    //对齐数组，取前三个。
    arrTea=arrTea.slice(0,3)
    //设定一个数字作为下标，用于点击变化
    let num = 0
    //设定一个点击事件，这里就不做长度判断了。
    function change(){
      if(num <person.length-1){
        num++
        console.log(num,person[num],teaPerson)   //看看对不对。
      }else{
        alert('没数据了')
      }
    }
    //根据下标获取数组中元素，当点击发生后，num变化，因此可以获取，但为什么不能获取呢？
    let personTea = ref(person[num])
    let teaPerson = ref(arrTea[num])

    return { 
      // ...toRefs(person),  
      // ...toRefs(tea),
      // person,
      // tea,
      change,
      personTea,
      teaPerson
    }
  },
}
</script>
<template>
  <!-- {{name}}爱喝{{foreign.indian}} -->
  {{personTea}}爱喝{{teaPerson}}
  <br>
  <button @click="change">换人按钮</button>
</template>
