<script>
import {ref, reactive, toRefs} from 'vue' 
export default{
  name: 'App',
  setup(){
    let inputedMoney = reactive({a:0, b:0, c:0, n:0})  //输入的值
    let outputMoneyArr = ref([])  //输出的多个值的嵌套数组，内部元素也为数组[ten, five, two]
    let isShow= ref(false)
    let resultOnShow=ref('')
    function calculator(a,b,c,n){
      // console.log(a,typeof(a))
      for(let i in [...Array(Number(a)+1).keys()]){
        for(let j in [...Array(Number(b)+1).keys()]){
          for(let k in [...Array(Number(c)+1).keys()]){
            // console.log('循环a',Number(a),i)
            if (Number(i)*10+Number(j)*5+Number(k)*2 === Number(n)){
              isShow.value = true
              resultOnShow.value = "能够凑齐" 
              outputMoneyArr.value.push([i, j, k])
              console.log(i,j,k)
            }
          }
        }
      }
      // console.log('此时的arr',outputMoneyArr)
      return outputMoneyArr
    }
    function calculate(){
      outputMoneyArr.value = []   //先清空上一次的结果，再运行
      calculator(inputedMoney.a,inputedMoney.b,inputedMoney.c,inputedMoney.n)
      if(outputMoneyArr.value.length===0){
        isShow.value = false
        resultOnShow.value = "凑不齐" 
      }
    }
    return {
      ...toRefs(inputedMoney),
      outputMoneyArr,
      isShow,
      resultOnShow,
      calculator,
      calculate
    }
  },
}
</script>

<template>
<h2>题目：手头有10元、5元、2元的钞票若干张，如果给一个固定的需要支付的金额，请问这个金额能用手头的钱正好凑齐吗？另外有几种办法凑齐？</h2>
  输入10元钱张数：<input text="text" placeholder="输入a整数" v-model ='a'>
  <br>
  输入5元钱张数：<input text="text" placeholder="输入b整数" v-model ='b'>
    <br>
  输入2元钱张数：<input text="text" placeholder="输入c整数" v-model ='c'>
    <br>
  输入需要支付的金额：<input text="text" placeholder="输入n整数" v-model ='n'>
  <hr>
  <button @click="calculate">计算</button>
  <hr>
  <h1>结果是：{{resultOnShow}}  </h1>
  <br>
  <ol v-show="isShow">
    <h3>有{{outputMoneyArr.length}}种方式，分别为：</h3>
    <li  v-for="(arr,index) in outputMoneyArr" :key="index">
      第{{index}}种方法：10元有{{arr[0]}}张，5元有{{arr[1]}}张，2元有{{arr[2]}}张
    </li>
  </ol>
</template>
